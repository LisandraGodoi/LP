﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto5_03._03_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double verif, verif2;

            if((double.TryParse(txtAltura.Text, out verif) &&
                double.TryParse(txtRaio.Text, out verif2)))
            {
                double volume = Math.PI * (verif2 * verif2) * verif;

                txtVolume.Text = volume.ToString("N2");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtRaio.Text = "";
            txtVolume.Text = "";
        }
    }
}
