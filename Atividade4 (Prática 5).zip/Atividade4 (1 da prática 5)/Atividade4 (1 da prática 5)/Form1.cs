﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade4__1_da_prática_5_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtAliquotaINSS_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            //MessageBox.Show("Me sinto idiota");

        }

        private void btnVerificarDesconto_Click(object sender, EventArgs e)
        {
            
            if(txtNomeFuncionário.Text == "")
            {
                MessageBox.Show("Insira o nome do funcionário");
            }
            else
            {
                // Ver se colocaram o número do salário certo//////////////////////////////////////////////////////////////////////
                double numSalBruto;

                if (double.TryParse(txtSalarioBruto.Text, out numSalBruto))
                {

                    //Verif filhos ////////////////////////////////////////////////////////;//////////////////////////////////////
                    double numFilhos;
                    double numDFAM = 0;
                    double numDIRPF = 0;
                    double iNSS = 0;

                    if (double.TryParse(txtNumeroFIlhos.Text, out numFilhos))
                    {
                        if (rdBtnFeminino.Checked)//////////////////////////// se é mulher/////////////
                        {
                            if (ckCasado.Checked)
                            {
                                lblDados.Text = "Os descontos de salario de " + txtNomeFuncionário.Text +
                                    ", que é casada e tem " + txtNumeroFIlhos.Text + " filho(s), são:";
                            }
                            else
                            {
                                lblDados.Text = "Os descontos de salario de " + txtNomeFuncionário.Text +
                                    ", que é solteira e tem " + txtNumeroFIlhos.Text + " filho(s), são:";
                            }
                        }
                        else if (rdBtnMasculino.Checked)////////////////////// se é homem /////////////
                        {
                            if (ckCasado.Checked)
                            {
                                lblDados.Text = "Os descontos de salario de " + txtNomeFuncionário.Text +
                                    ", que é casado e tem " + txtNumeroFIlhos.Text + " filho(s), são:";
                            }
                            else
                            {
                                lblDados.Text = "Os descontos de salario de " + txtNomeFuncionário.Text +
                                    ", que é solteiro e tem " + txtNumeroFIlhos.Text + " filho(s), são:";
                            }
                        }
                        else ////////////////////////////// colocou nenhum //////////////////////
                        {
                            if (ckCasado.Checked)
                            {
                                lblDados.Text = "Os descontos de salario de " + txtNomeFuncionário.Text +
                                    ", que é casado(a) e tem " + txtNumeroFIlhos.Text + " filho(s), são:";
                            }
                            else
                            {
                                lblDados.Text = "Os descontos de salario de " + txtNomeFuncionário.Text +
                                    ", que é solteiro(a) e tem " + txtNumeroFIlhos.Text + " filho(s), são:";
                            }
                        }
                        //////////////////////////////////////////////////////////////////////////////////////////////////////////
                        /////////////////////////////////////////// CALCULO INSS ///////////////////////////////////////////////////////
                        /*Aliquota INSS para Salário Bruto:
                        Até 800.47 - 7.65 %/////////////////////////
                        De 800.48 a 1050 - 8.65 %///////////////////
                        De 1050.01 a 1400.77 – 9.00 %///////////////
                        De 1400.78 a 2801.56 – 11.00 %//////////////
                        > 2801.56->Desconto = 308.17(teto)*/


                        if (numSalBruto <= 800.47) ///////////////////////Até 800.47 - 7.65 %
                        {
                            double a;
                            txtAliquotaINSS.Text = "7,65%";
                            a = 7.65 / 100 * numSalBruto;
                            iNSS = a;
                            txtDescontoINSS.Text = a.ToString();
                        }
                        else if (numSalBruto <= 1050) ///////////////// De 800.48 a 1050 - 8.65 %
                        {
                            double a;
                            txtAliquotaINSS.Text = "8,65%";
                            a = 8.65 / 100 * numSalBruto;
                            iNSS = a;
                            txtDescontoINSS.Text = a.ToString();
                        }
                        else if (numSalBruto <= 1400.77)//////////////// De 1050.01 a 1400.77 – 9.00 %
                        {
                            double a;
                            txtAliquotaINSS.Text = "9,00%";
                            a = 9.00 / 100 * numSalBruto;
                            iNSS = a;
                            txtDescontoINSS.Text = a.ToString();
                        }
                        else if (numSalBruto <= 2801.56)//////////////// De 1400.78 a 2801.56 – 11.00 %
                        {
                            double a;
                            txtAliquotaINSS.Text = "11,00%";
                            a = 11.00 / 100 * numSalBruto;
                            iNSS = a;
                            txtDescontoINSS.Text = a.ToString();
                        }
                        else if (numSalBruto > 2801.56) /////////////////////////////////////////////> 2801.56->Desconto = 308.17(teto)*/
                        {
                            iNSS = 308.17;
                            txtAliquotaINSS.Text = "R$308.17";
                            txtDescontoINSS.Text = "308.17";
                        }

                        //////////////////////////////////////////////////////////////////////////////////////////////////////////
                        /////////////////////////////////////////// CALCULO IRPF///////////////////////////////////////////////////////
                        /*Alíquota IRPF para Salário Bruto:
                        Até 1257.12 - isento////////////////////////
                        De 1257.13 a 2512.08 – 15.00% //////////////
                        > 2512.08 - 27.5% 
                         */

                        if (numSalBruto <= 1257.12) /////////////////////// Até 800.47 - 7.65 %
                        {
                            txtAliquotaIRPF.Text = "Isento";
                            txtDescontoIRPF.Text = "00.00";
                            numDIRPF = 0;
                        }
                        else if (numSalBruto > 1257.13 && numSalBruto < 2512.09) ///////////////// De 1257.13 a 2512.08 – 15.00%
                        {
                            double a;
                            txtAliquotaIRPF.Text = "15%";
                            a = 15.00 / 100 * numSalBruto;
                            numDIRPF = a;
                            txtDescontoIRPF.Text = a.ToString();
                        }
                        else if (numSalBruto > 2512.08) //////////////////////////////////////////// > 2512.08 - 27.5% 
                        {
                            double a;
                            txtAliquotaIRPF.Text = "27.5%";
                            a = 27.5 / 100 * numSalBruto;
                            numDIRPF = a;
                            txtDescontoIRPF.Text = a.ToString();
                        }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////// CALCULO família ///////////////////////////////////////////////////////
    /* Até 435.52 - 22.33 por filho ////////////////////
     De 435.53 a 654.61 - 15.74 por filho
     >654.61 – 0 
     */
    ;
                        if (numSalBruto <= 435.52) ///////////////// Até 435.52 - 22.33 por filho 
                        {
                            double a;
                            a = 22.33 * numFilhos;
                            numDFAM = a;
                            txtSalarioFamilia.Text = a.ToString();
                        }
                        else if (numSalBruto <= 654.61) ///////////////// De 435.53 a 654.61 - 15.74 por filho
                        {
                            double a;
                            a = 15.74 * numFilhos;
                            numDFAM = a;
                            txtSalarioFamilia.Text = a.ToString();
                        }
                        else ////////////////////////////////////////// >654.61 – 0 
                        {
                            double a;
                            a = 0 * numFilhos;
                            numDFAM = a;
                            txtSalarioFamilia.Text = a.ToString();
                        }
                        //////////////////////////////////////////////////////////////////////////////////////////////////////////
                        /////////////////////////////////////////// CALCULO SAL LIQUIDO ///////////////////////////////////////////////////////
                        /* Salário Líquido = Salário Bruto – Desconto INSS – Desconto IRPF + Salário Família 
                         */
                        double salAux;



                        salAux = numSalBruto - iNSS - numDIRPF + numDFAM;
                        txtSalarioLiquido.Text = salAux.ToString();


                    }
                    else//////////////// COLOCARAM LETRAS NOS FILHOS/////////////////////////////////////////////////////////////////
                    {
                        MessageBox.Show("Insira um valor numérico em Número de Filhos");
                    }
                }
                else ///////////////////////// COLOCARAM LETRAS NOS SALÁRIOS //////////////////////////////////////////////////////////////
                {
                    MessageBox.Show("Insira um valor numérico em Salário Bruto");
                }
            }
            
        }
    }
}
