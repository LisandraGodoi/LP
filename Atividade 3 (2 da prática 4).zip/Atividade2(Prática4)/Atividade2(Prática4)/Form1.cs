﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade2_Prática4_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnTeste_Click(object sender, EventArgs e)
        {
            double a, b, c;

            if(double.TryParse(txtValorUm.Text, out a) &&
               double.TryParse(txtValorDois.Text, out b) &&
               double.TryParse(txtValorTres.Text, out c))
            {
                if ((a == null) || (b == null) || (c == null)) //////// se um dos valores for nulo
                {
                    MessageBox.Show("Insira 3 valores não nulos");
                }
                else /// se não for nulo //////////////////////////////////////////////////////////////////
                {
                    if ((b - c) < a && a < (b + c)) ///////// regra A //////////////////////////////////////////////////
                    {
                        if ((a - c) < b && b < (a + c)) /////// regra B /////////////////////////////////////////////
                        {
                            if ((a - b) < c && c < (a + b))////// regra C ///////////////////////////////////////////
                            {
                                ////////////////////////////////////////////////////////////////////////////////
                                //////////////// PODE SER UM TRIANGULO MAS TEM QUE DIZER QUAL///////////////////
                                ////////////////////////////////////////////////////////////////////////////////


                                if (a == b && a == c && b == c) /////////// equilátero////////////////////////////// 
                                {
                                    MessageBox.Show("O triângulo informado é EQUILÁTERO");
                                }
                                else if ((a == b) || (a == c) || (c == b))///////// isóceles///////////////////// 
                                {
                                    MessageBox.Show("O triângulo informado é ISÓCELES");
                                }
                                else if ((a != b) && (a != c) && (b != c))///////// escaleno /////////////////////
                                {
                                    MessageBox.Show("O triângulo informado é ESCALENO");
                                }
                            }
                            else ///////////// se o C não obedecer a regra //////////////////////////////////////
                            {
                                MessageBox.Show("Os valores não podem pertencer aos lados de um triângulo");
                            }
                        }
                        else ///////////////// se o B não obedecer a regra //////////////////////////////////////
                        {
                            MessageBox.Show("Os valores não podem pertencer aos lados de um triângulo");
                        }
                    }
                    else ///////////////////// se o A não obedecer a regra///////////////////////////////////////
                    {
                        MessageBox.Show("Os valores não podem pertencer aos lados de um triângulo");
                    }
                }
            }//////////////////////////// else Inseriram caracter ///////////////////////////////////////////
            else
            {
                MessageBox.Show("Por favor insira 3 valores numéricos");
            }
        }
    }
}
